<?php
require_once __DIR__ . '/ControllerAction.php';
require_once __DIR__ . '/../models/TopicDAO.php';
require_once __DIR__ . '/../models/Topic.php';
require_once __DIR__ . '/../models/ArticleDAO.php';
require_once __DIR__ . '/../models/Article.php';
require_once __DIR__ . '/../models/CommentDAO.php';
require_once __DIR__ . '/../models/Comment.php';

class TopicAdd implements ControllerAction {
    public function processGET() {
        return 'views/addTopic.php';
    }

    public function processPOST() {
        $name = $_POST['name'] ?? '';
        $description = $_POST['description'] ?? '';

        $topic = new Topic();
        $topic->setName($name);
        $topic->setDescription($description);

        $topicDAO = new TopicDAO();
        $topicDAO->addTopic($topic);

        header('Location: controller.php?page=listTopics');
        exit;
    }

    public function getAccess() {
        return 'PROTECTED';
    }
}

class TopicList implements ControllerAction {
    public function processGET() {
        $topicDAO = new TopicDAO();
        $topics = $topicDAO->getTopics();
        $_REQUEST['topics'] = $topics;
        return 'views/home.php';
    }

    public function processPOST() { }

    public function getAccess() {
        return 'PUBLIC';
    }
}

class ArticleAdd implements ControllerAction {
    public function processGET() {
        $topicDAO = new TopicDAO();
        $topics = $topicDAO->getTopics();
        $_REQUEST['topics'] = $topics;
        return 'views/addArticle.php';
    }

    public function processPOST() {
        session_start();

        $authorID = $_SESSION['userID'] ?? 0;
        $title    = $_POST['title']    ?? '';
        $catID    = $_POST['catID']    ?? 0;
        $image    = $_POST['image']    ?? '';
        $content  = $_POST['content']  ?? '';

        $article = new Article();
        $article->setAuthorID($authorID);
        $article->setCatID($catID);
        $article->setTitle($title);
        $article->setImage($image);
        $article->setContent($content);

        $articleDAO = new ArticleDAO();
        $articleDAO->addArticle($article);

        header('Location: controller.php?page=GEThome');
        exit;
    }

    public function getAccess() {
        return 'PROTECTED';
    }
}

class ArticleList implements ControllerAction {
    public function processGET() {
        $articleDAO = new ArticleDAO();
        $articles = $articleDAO->getArticles();

        $commentDAO = new CommentDAO();
        $comments = $commentDAO->getAllComments();

        $_REQUEST['articles'] = $articles;
        $_REQUEST['comments'] = $comments;

        return 'views/viewBlog.php';
    }

    public function processPOST() { }

    public function getAccess() {
        return 'PUBLIC';
    }
}

class CommentAdd implements ControllerAction {
    public function processGET() {
        header('Location: controller.php?page=listArticles');
        exit;
    }

    public function processPOST() {
        session_start();
        $artID     = $_POST['artID'] ?? 0;
        $authorID  = $_SESSION['userID'] ?? 0;
        $content   = $_POST['text'] ?? '';

        if ($artID && $content) {
            $comment = new Comment();
            $comment->setArtID($artID);         // FIXED: was setArticleID()
            $comment->setAuthorID($authorID);
            $comment->setContent($content);

            $commentDAO = new CommentDAO();
            $commentDAO->addComment($comment);
        }

        header('Location: controller.php?page=listArticles');
        exit;
    }

    public function getAccess() {
        return 'PROTECTED';
    }
}


class CommentList implements ControllerAction {
    public function processGET() {
        $commentDAO = new CommentDAO();
        $comments = $commentDAO->getAllComments();
        $_REQUEST['comments'] = $comments;
        return 'views/listComments.php';
    }

    public function processPOST() { }

    public function getAccess() {
        return 'PUBLIC';
    }
}
