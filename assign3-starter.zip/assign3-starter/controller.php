<?php
include_once "controllers/ControllerAction.php";
include_once "controllers/ContactControllers.php";
include_once "controllers/BlogControllers.php";
include_once "models/ContactDAO.php";

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

class FrontController {
    private $controllers;

    public function __construct() {
        $this->showErrors(1);
        $this->controllers = $this->loadControllers();
    }

    public function run() {
        session_start();

        $method = $_SERVER['REQUEST_METHOD'];
        $page   = $_REQUEST['page'] ?? 'home';

        $key        = $method . $page;
        $controller = $this->controllers[$key] ?? $this->controllers["GEThome"];
        
        $controller = $this->securityCheck($controller);

        if ($method === 'GET') {
            $content = $controller->processGET();
        } else {
            $content = $controller->processPOST();
        }

        // Pass $_REQUEST data to template
        $this->renderTemplate($content, $_REQUEST);
    }

    private function renderTemplate($content, $data) {
        extract($data);  // make keys available as local variables
        include "template/template.php";
    }

    private function loadControllers() {
        $controllers["GETlist"]         = new ContactList();
        $controllers["GETadd"]          = new ContactAdd();
        $controllers["POSTadd"]         = new ContactAdd();
        $controllers["GETdelete"]       = new ContactDelete();
        $controllers["POSTdelete"]      = new ContactDelete();
        $controllers["GETlogin"]        = new Login();
        $controllers["POSTlogin"]       = new Login();
        $controllers["GEThome"]         = new Home();
        $controllers["GETabout"]        = new About();

        $controllers["GETaddTopic"]     = new TopicAdd();
        $controllers["POSTaddTopic"]    = new TopicAdd();
        $controllers["GETlistTopics"]   = new TopicList();

        // Add Article Routes
        $controllers["POSTaddArticle"]  = new ArticleAdd();  // Map POST to the right controller
        $controllers["GETaddArticle"]   = new ArticleAdd();  // For GET request, show addArticle form
        $controllers["GETlistArticles"] = new ArticleList();

        // Comment Routes
        $controllers["GETaddComment"]   = new CommentAdd();
        $controllers["POSTaddComment"]  = new CommentAdd();
        $controllers["GETlistComments"] = new CommentList();

        return $controllers;
    }

    private function securityCheck($controller) {
        if ($controller->getAccess() === 'PROTECTED' && empty($_SESSION['loggedin'])) {
            return $this->controllers["GETlogin"];
        }
        return $controller;
    }

    private function showErrors($debug) {
        if ($debug === 1) {
            ini_set('display_errors', 1);
            ini_set('display_startup_errors', 1);
            error_reporting(E_ALL);
        }
    }
}

$controller = new FrontController();
$controller->run();
