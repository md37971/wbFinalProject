<?php
  if(isset($_SESSION['loggedin'])){
    $status="Logged In";
    $class="disabled";
  }else{
    $status="Login";
    $class="";
  }
?>
<style>
  #head ul{
    overflow: hidden;
    list-style-position: inside;
    margin: 0px;
  }

  #head li{
    text-align: left;
    float: left;
    margin-right: 25px;
    list-style-type: none;
    margin-left: 5px;
    font-size: 20px;
  }

  #head li:hover {
    background-color: rgb(192, 190, 190);
    border-radius: 25px;
  }

  #home {
    list-style-image: url(images/home.svg);
  }

  #about {
    list-style-image: url(images/question.svg);
  }

  #admin {
    list-style-image: url(images/wrench.svg);
  }

  
</style>
<header class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-body border-bottom shadow-sm">
  <h1 class="h5 my-0 me-md-auto fw-normal">CS 2033: Web Systems MVC Pattern with Authorization</h1>
  <nav class="my-2 my-md-0 me-md-3" id="head">
    <ul>
    <li id="home"><a class="p-2 text-dark" href="controller.php?page=home">Home</a></li>
    <li id="about"><a class="p-2 text-dark" href="controller.php?page=about">About</a></li>
    <li id="admin"><a class="p-2 text-dark" href="controller.php?page=list">Admin</a></li>
   </nav>
  </ul>
  <a class="btn btn-outline-primary <?php echo $class; ?>" href="controller.php?page=login"><?php echo $status; ?></a>
</header>