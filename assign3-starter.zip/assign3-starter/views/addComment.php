<form action="controller.php" method="POST">
    <input type="hidden" name="page" value="addComment">

    <label for="articleID" class="form-label">Select Article</label>
    <select name="articleID" class="form-select mb-3" required>
        <?php foreach ($_REQUEST['articles'] as $article): ?>
            <option value="<?= $article->getArtID() ?>">
                <?= htmlspecialchars($article->getTitle()) ?>
            </option>
        <?php endforeach; ?>
    </select>

    <label for="author" class="form-label">Your Name</label>
    <input type="text" name="author" class="form-control mb-3" required>

    <label for="text" class="form-label">Comment</label>
    <textarea name="text" class="form-control mb-3" required></textarea>

    <button type="submit" class="btn btn-success">Submit Comment</button>
</form>
