<?php
$mysqli = new mysqli('localhost', 'bloguser', 'blogAssign3', 'blogdb');
$topics = [];
if (!$mysqli->connect_errno) {
    $result = $mysqli->query("SELECT * FROM topics");
    while ($row = $result->fetch_assoc()) {
        $topics[] = $row;
    }
    $mysqli->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adding an Article</title>
    <h1 style="text-align: center">Blog Manager</h1>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
</head>
<body>
    <div class="container">
      <div class="row">
        <div class="col">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Blog Manager</h5>
              <p class="card-text">Add a new article.</p>
              <form action="../controller.php" method="POST"> <!-- <-- NOTE THE FIXED PATH -->
                <input type="hidden" name="page" value="addArticle">

                <label for="title" class="form-label">Title</label>
                <input type="text" class="form-control mb-3" id="title" name="title" placeholder="Enter article title" required>

                <label for="catID" class="form-label">Topic</label>
                <select id="catID" name="catID" class="form-select mb-3" required>
                  <option value="" disabled selected>Choose a topic…</option>
                  <?php if (!empty($topics)): ?>
                    <?php foreach ($topics as $t): ?>
                      <option value="<?= $t['topID'] ?>">
                        <?= htmlspecialchars($t['name']) ?>
                      </option>
                    <?php endforeach; ?>
                  <?php else: ?>
                    <option value="">(No topics available)</option>
                  <?php endif; ?>
                </select>

                <label for="image" class="form-label">Image URL</label>
                <input type="url" class="form-control mb-3" id="image" name="image" placeholder="https://example.com/image.jpg">

                <label for="content" class="form-label">Content</label>
                <textarea id="content" name="content" class="form-control mb-3" rows="5" placeholder="Write your article…" required></textarea>

                <button type="submit" class="btn btn-primary" style="background-color: green">Submit</button>
              </form>
            </div>
          </div>      
        </div>
      </div>
    </div>
</body>
</html>
