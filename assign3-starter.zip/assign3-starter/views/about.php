<?php

$status   = isset($_SESSION['loggedin']) ? "Logged In" : "Login";
$class    = isset($_SESSION['loggedin']) ? "disabled"  : "";
?>
<!DOCTYPE html>
<html lang="en">
<style>
  #con1 {
    background-color: 	rgb(232,232,232)
  }
</style>

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About Section</title>
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
    rel="stylesheet"
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
    crossorigin="anonymous">
</head>

<body>



  <main class="container1" id="con1">
    <div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
      <h1 class="display-4"><b>About</b></h1>
      <p class="lead"><b>Welcome to the Web Systems Blogsite!</b></p>
      <hr>
      <p>
        The purpose of this blog site is to promote communication among others and be able to socialize what's currently happening
        around the world, whether it's friends, family, or even strangers!
      </p>
      <br>
      <p>This website was made possible by a web system project that was assigned as a final project.</p>
    </div>
  </main>


  <main class="container">
  <div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
    <h3 class="display-4">Meet the Web developers!</h3>
  </div>

  <div class="row row-cols-1 row-cols-md-3 mb-3 text-center">


    <div class="col">
      <div class="card mb-4 shadow-sm">
      <div class="card-header">
        <h4 class="my-0 fw-normal">Michael Delgado</h4>
      </div>
      <div class="card-body">
        <h1 class="card-title pricing-card-title">DESIGNER</h1>
        <img src="images/lion.png"></img>
        <ul class="list-unstyled mt-3 mb-4">
          <li>Student at the University of Arkansas Fort Smith.</i>
          <li>Involved in Web Systems Project</li>
        </ul>
        <a href="https://github.com/md37971/wbFinalProject"><button type="button" class="w-100 btn btn-lg btn-primary">Get in touch!</button></a>
      </div>
    </div>
    </div>



    <div class="col">
      <div class="card mb-4 shadow-sm">
      <div class="card-header">
        <h4 class="my-0 fw-normal">Skyler Smith</h4>
      </div>
      <div class="card-body">
        <h1 class="card-title pricing-card-title">PHP PROGRAMMING</h1>
        <img src="images/lion.png"></img>
        <ul class="list-unstyled mt-3 mb-4">
          <li>Student at the University of Arkansas Fort Smith.</i>
          <li>Involved in Web Systems Project</li>
        </ul>
        <a href="https://youtube.com/c/SkyproductionsYT"><button type="button" class="w-100 btn btn-lg btn-primary">Get in touch!</button></a>
      </div>
    </div>
    </div>


    <div class="col">
      <div class="card mb-4 shadow-sm">
      <div class="card-header">
        <h4 class="my-0 fw-normal">Thomas Nguyen</h4>
      </div>
      <div class="card-body">
        <h1 class="card-title pricing-card-title">DEVELOPER</h1>
        <img src="images/lion.png"></img>
        <ul class="list-unstyled mt-3 mb-4">
          <li>Student at the University of Arkansas Fort Smith.</i>
          <li>Involved in Web Systems Project</li>
        </ul>
        <a href="https://github.com/md37971/wbFinalProject"><button type="button" class="w-100 btn btn-lg btn-primary">Get in touch!</button></a>
      </div>
    </div>
    </div>

    <div class="col">
      <div class="card mb-4 shadow-sm">
      <div class="card-header">
        <h4 class="my-0 fw-normal">John Bui</h4>
      </div>
      <div class="card-body">
        <h1 class="card-title pricing-card-title">DEVELOPER</h1>
        <img src="images/lion.png"></img>
        <ul class="list-unstyled mt-3 mb-4">
          <li>Student at the University of Arkansas Fort Smith.</i>
          <li>Involved in Web Systems Project</li>
        </ul>
        <a href="https://github.com/md37971/wbFinalProject"><button type="button" class="w-100 btn btn-lg btn-primary">Get in touch!</button></a>
      </div>
    </div>
    </div>
  </div>
</main>
</body>
  <footer class="pt-4 my-md-5 pt-md-5 border-top">
    <!-- footer content unchanged -->
  </footer>
</body>
</html>
