<!DOCTYPE html>
<?php
$articles = $_REQUEST['articles'] ?? [];
$comments = $_REQUEST['comments'] ?? [];
$topics   = $_REQUEST['topics'] ?? [];
?>

<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Home</title>
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
    rel="stylesheet"
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
    crossorigin="anonymous">
  <style>
    .article {
      display: flex;
      flex-wrap: wrap;
      gap: 2%;
      margin-bottom: 2rem;
    }
    .theTable {
      flex: 1 1 48%;
    }
    .theTable h3 {
      margin-bottom: .5rem;
    }
  </style>
</head>
<body>
  <div class="container py-4">

    <!-- Login button top-right -->
    <div class="d-flex justify-content-end mb-3">
      <a href="login.php" class="btn btn-outline-primary">Login</a>
    </div>

    <!-- Row 1: Articles only -->
    <div class="article">
      <div class="theTable">
        <div class="d-flex justify-content-between align-items-center mb-2">
          <h3><u>Articles</u></h3>
          <button class="btn btn-sm btn-primary"
                  onclick="location.href='views/addArticle.php'">
            Add Article
          </button>
        </div>
        <table class="table table-bordered table-striped">
          <thead class="table-dark">
            <tr><th>#</th><th>Title</th><th>Category</th><th>View</th></tr>
          </thead>
          <tbody>
            <?php if (!empty($articles)): ?>
              <?php foreach ($articles as $a): ?>
                <tr>
                  <td><?= $a->getArtID() ?></td>
                  <td><?= htmlspecialchars($a->getTitle()) ?></td>
                  <td><?= $a->getCatID() ?></td>
                  <td>
                    <button class="btn btn-sm btn-secondary"
                            onclick="location.href='views/viewBlog.php?artID=<?= $a->getArtID() ?>'">
                      View
                    </button>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php else: ?>
              <tr><td colspan="4" class="text-center">No articles.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Row 2: Topics & Comments -->
    <div class="article">
      <!-- Topics -->
      <div class="theTable">
        <div class="d-flex justify-content-between align-items-center mb-2">
          <h3><u>Topics</u></h3>
          <button class="btn btn-sm btn-primary"
                  onclick="location.href='views/addTopic.php'">
            Add Topic
          </button>
        </div>
        <table class="table table-bordered table-striped">
          <thead class="table-dark">
            <tr><th>#</th><th>Name</th><th>Description</th></tr>
          </thead>
          <tbody>
            <?php if (!empty($topics)): ?>
              <?php foreach ($topics as $t): ?>
                <tr>
                  <td><?= $t->getTopID() ?></td>
                  <td><?= htmlspecialchars($t->getName()) ?></td>
                  <td><?= htmlspecialchars($t->getDescription()) ?></td>
                </tr>
              <?php endforeach; ?>
            <?php else: ?>
              <tr><td colspan="3" class="text-center">No topics.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <!-- Comments -->
      <div class="theTable">
        <div class="d-flex align-items-center mb-2">
          <h3><u>Comments</u></h3>
        </div>
        <table class="table table-bordered table-striped">
          <thead class="table-dark">
            <tr><th>#</th><th>Article #</th><th>Content</th></tr>
          </thead>
          <tbody>
            <?php if (!empty($comments)): ?>
              <?php foreach ($comments as $cm): ?>
                <tr>
                  <td><?= $cm->getComID() ?></td>
                  <td><?= $cm->getArtID() ?></td>
                  <td><?= htmlspecialchars($cm->getContent()) ?></td>
                </tr>
              <?php endforeach; ?>
            <?php else: ?>
              <tr><td colspan="3" class="text-center">No comments.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

  </div>
</body>
</html>
