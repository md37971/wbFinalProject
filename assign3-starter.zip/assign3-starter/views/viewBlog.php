<?php
$mysqli = new mysqli('localhost', 'bloguser', 'blogAssign3', 'blogdb');

// fetch all data
$articles = [];
$comments = [];
$topics   = [];
$users    = [];

if (!$mysqli->connect_errno) {
    $artResult = $mysqli->query("SELECT * FROM articles");
    while ($row = $artResult->fetch_assoc()) {
        $articles[] = $row;
    }

    $comResult = $mysqli->query("SELECT * FROM comments");
    while ($row = $comResult->fetch_assoc()) {
        $comments[] = $row;
    }

    $topicResult = $mysqli->query("SELECT * FROM topics");
    while ($row = $topicResult->fetch_assoc()) {
        $topics[] = $row;
    }

    $userResult = $mysqli->query("SELECT * FROM users");
    while ($row = $userResult->fetch_assoc()) {
        $users[] = $row;
    }

    $mysqli->close();
}

// build lookup tables
$usernames = [];
foreach ($users as $u) {
    $usernames[$u['userID']] = $u['username'];
}
$topicNames = [];
foreach ($topics as $t) {
    $topicNames[$t['topID']] = $t['name'];
}

// detect selected article
$selectedArtID = $_GET['artID'] ?? null;
$selectedArticle = null;
$selectedComments = [];
if ($selectedArtID) {
    foreach ($articles as $a) {
        if ($a['artID'] == $selectedArtID) {
            $selectedArticle = $a;
            break;
        }
    }
    foreach ($comments as $c) {
        if ($c['artID'] == $selectedArtID) {
            $selectedComments[] = $c;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>All Blog Articles</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container py-5">
  <h1 class="text-center mb-4">All Blog Articles</h1>

  <table class="table table-bordered table-striped">
    <thead>
      <tr>
        <th>Title</th>
        <th>Author</th>
        <th>Topic</th>
        <th>Comments</th>
        <th>Last Modified</th>
        <th>View</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($articles as $art): 
          $cnt = 0;
          foreach ($comments as $c) {
              if ($c['artID'] == $art['artID']) {
                  $cnt++;
              }
          }
      ?>
      <tr>
        <td><?= htmlspecialchars($art['title']) ?></td>
        <td><?= htmlspecialchars($usernames[$art['authorID']] ?? 'Unknown') ?></td>
        <td><?= htmlspecialchars($topicNames[$art['catID']] ?? 'Unknown') ?></td>
        <td><?= $cnt ?></td>
        <td><?= htmlspecialchars($art['lastModified']) ?></td>
        <td>
          <a class="btn btn-sm btn-primary" href="viewBlog.php?artID=<?= $art['artID'] ?>">View</a>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <div class="mt-5">
    <a class="btn btn-success mb-3" href="/assign3-starter/controller.php?page=addArticle">Add New Article</a>
  </div>

  <?php if ($selectedArticle): ?>
    <div class="card mt-4">
      <div class="card-body">
        <h3><?= htmlspecialchars($selectedArticle['title']) ?></h3>
        <?php if (!empty($selectedArticle['image'])): ?>
          <img src="<?= htmlspecialchars($selectedArticle['image']) ?>" class="img-fluid mb-3" alt="Article Image">
        <?php endif; ?>
        <p><?= nl2br(htmlspecialchars($selectedArticle['content'])) ?></p>
        <p><strong>Topic:</strong> <?= htmlspecialchars($topicNames[$selectedArticle['catID']] ?? 'Unknown') ?></p>
        <p><strong>Author:</strong> <?= htmlspecialchars($usernames[$selectedArticle['authorID']] ?? 'Unknown') ?></p>
        <p><strong>Last Modified:</strong> <?= htmlspecialchars($selectedArticle['lastModified']) ?></p>
      </div>
    </div>

    <div class="card mt-4">
      <div class="card-body">
        <h5>Add a Comment</h5>
        <form action="/assign3-starter/controller.php" method="POST">
          <input type="hidden" name="page" value="addComment">
          <input type="hidden" name="artID" value="<?= $selectedArticle['artID'] ?>">

          <label for="text" class="form-label">Your Comment</label>
          <textarea class="form-control mb-3" name="text" rows="3" required></textarea>

          <button type="submit" class="btn btn-primary">Submit Comment</button>
        </form>
      </div>
    </div>

    <div class="mt-4">
      <h5>Existing Comments</h5>
      <?php if (empty($selectedComments)): ?>
        <p>No comments yet.</p>
      <?php else: ?>
        <ul class="list-group">
          <?php foreach ($selectedComments as $c): ?>
            <li class="list-group-item">
              <strong>User #<?= htmlspecialchars($c['authorID']) ?>:</strong>
              <?= htmlspecialchars($c['content']) ?>
              <br><small><?= htmlspecialchars($c['lastModified']) ?></small>
            </li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>
    </div>
  <?php endif; ?>
</div>
</body>
</html>
