<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adding a Topic</title>
    <h1 style="text-align: center">Topic Manager</h1>
    <link 
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" 
      rel="stylesheet" 
      integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" 
      crossorigin="anonymous">
</head>
<body>
    <div class="container">
      <div class="row">
        <div class="col">
          <div class="card mt-4">
            <div class="card-body">
              <h5 class="card-title">Topic Manager</h5>
              <p class="card-text">Add a new topic to the list.</p>

              <
              <form action="../controller.php" method="POST">
                <input type="hidden" name="page" value="addTopic">

                <div class="mb-3">
                  <label for="name" class="form-label">Topic Name</label>
                  <input 
                    type="text" 
                    class="form-control" 
                    id="name" 
                    name="name" 
                    placeholder="Enter topic name" 
                    required>
                </div>

                <div class="mb-3">
                  <label for="description" class="form-label">Description</label>
                  <input 
                    type="text" 
                    class="form-control" 
                    id="description" 
                    name="description" 
                    placeholder="Enter topic description">
                </div>

                <button 
                  type="submit" 
                  class="btn btn-primary"
                  style="background-color: green">
                  Submit
                </button>
              </form>

            </div>
          </div>      
        </div>
      </div>
    </div>
</body>
</html>
