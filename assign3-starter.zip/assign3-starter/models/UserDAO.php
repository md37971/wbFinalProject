<?php
include_once 'User.php';

class UserDAO {
    private function getConnection() {
        $m = new mysqli('localhost', 'bloguser', 'blogAssign3', 'blogdb');
        return $m->connect_errno ? null : $m;
    }

    public function getUsers(): array {
        $conn = $this->getConnection();
        $out  = [];
        if ($conn) {
            $res = $conn->query("SELECT * FROM users");
            while ($row = $res->fetch_assoc()) {
                $u = new User();
                $u->load($row);
                $out[] = $u;
            }
            $conn->close();
        }
        return $out;
    }

    public function addUser(User $u): void {
        $c = $this->getConnection();
        if (!$c) return;

        $stmt = $c->prepare(
            "INSERT INTO users (username, lastname, firstname, password, email, role) VALUES (?, ?, ?, ?, ?, ?)"
        );
        $stmt->bind_param(
            "ssssss",
            $u->getUsername(),
            $u->getLastname(),
            $u->getFirstname(),
            $u->getPassword(),
            $u->getEmail(),
            $u->getRole()
        );
        $stmt->execute();
        $stmt->close();
        $c->close();
    }

    public function deleteUser(int $id): void {
        $c = $this->getConnection();
        if (!$c) return;
        $stmt = $c->prepare("DELETE FROM users WHERE userID = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();
        $c->close();
    }
}
?>