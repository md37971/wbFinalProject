<?php

include_once 'Blog.php';

class BlogDAO {
    private function getConnection() {
        $m = new mysqli('127.0.0.1','bloguser','blogAssign3','blogdb');
        return $m->connect_errno ? null : $m;
    }

    // ── USERS ───────────────────────────────────────────────────────────────────

    public function getUsers(): array {
        $conn = $this->getConnection();
        $stmt = $conn->prepare("SELECT * FROM users");
        $stmt->execute();
        $res = $stmt->get_result();
        $out = [];
        while($row = $res->fetch_assoc()) {
            $u = new User();
            $u->load($row);
            $out[] = $u;
        }
        $stmt->close();
        $conn->close();
        return $out;
    }

    public function addUser(User $u): void {
        $c = $this->getConnection();
        $stmt = $c->prepare(
          "INSERT INTO users (username, lastname, firstname, password, email, role)
           VALUES (?, ?, ?, ?, ?, ?)"
        );
        $stmt->bind_param(
          "ssssss",
          $u->getUsername(),
          $u->getLastname(),
          $u->getFirstname(),
          $u->getPassword(),
          $u->getEmail(),
          $u->getRole()
        );
        $stmt->execute();
        $stmt->close();
        $c->close();
    }

    public function deleteUser(int $id): void {
        $c = $this->getConnection();
        $stmt = $c->prepare("DELETE FROM users WHERE userID = ?");
        $stmt->bind_param("i",$id);
        $stmt->execute();
        $stmt->close();
        $c->close();
    }

    // ── TOPICS ──────────────────────────────────────────────────────────────────

    public function getTopics(): array {
        $c = $this->getConnection();
        $stmt = $c->prepare("SELECT * FROM topics");
        $stmt->execute();
        $res = $stmt->get_result();
        $out = [];
        while($r = $res->fetch_assoc()) {
            $t = new Topic(); $t->load($r);
            $out[] = $t;
        }
        $stmt->close(); $c->close();
        return $out;
    }

    public function addTopic(Topic $t): void {
        $c = $this->getConnection();
        $stmt = $c->prepare("INSERT INTO topics (name, description) VALUES (?, ?)");
        $stmt->bind_param("ss",$t->getName(), $t->getDescription());
        $stmt->execute();
        $stmt->close(); $c->close();
    }

    public function deleteTopic(int $id): void {
        $c = $this->getConnection();
        $stmt = $c->prepare("DELETE FROM topics WHERE topID = ?");
        $stmt->bind_param("i",$id);
        $stmt->execute();
        $stmt->close(); $c->close();
    }

    // ── ARTICLES ────────────────────────────────────────────────────────────────

    public function getArticles(): array {
        $c = $this->getConnection();
        $stmt = $c->prepare("SELECT * FROM articles");
        $stmt->execute();
        $res = $stmt->get_result();
        $out = [];
        while($r = $res->fetch_assoc()) {
            $a = new Article(); $a->load($r);
            $out[] = $a;
        }
        $stmt->close(); $c->close();
        return $out;
    }

    public function addArticle(Article $a): void {
        $c = $this->getConnection();
        $stmt = $c->prepare(
          "INSERT INTO articles (authorID, catID, title, image, content)
           VALUES (?, ?, ?, ?, ?)"
        );
        $stmt->bind_param(
          "iisss",
          $a->getAuthorID(),
          $a->getCatID(),
          $a->getTitle(),
          $a->getImage(),
          $a->getContent()
        );
        $stmt->execute();
        $stmt->close(); $c->close();
    }
        /**
     * Fetch all articles in a given topic (category).
     *
     * @param int $topicID
     * @return Article[]
     */
    public function getArticlesByTopic(int $topicID): array {
        $conn = $this->getConnection();
        $out  = [];

        if ($conn) {
            $stmt = $conn->prepare("SELECT * FROM articles WHERE catID = ?");
            $stmt->bind_param("i", $topicID);
            $stmt->execute();
            $res = $stmt->get_result();

            while ($row = $res->fetch_assoc()) {
                $a = new Article();
                $a->load($row);
                $out[] = $a;
            }

            $stmt->close();
            $conn->close();
        }

        return $out;
    }


    public function deleteArticle(int $id): void {
        $c = $this->getConnection();
        $stmt = $c->prepare("DELETE FROM articles WHERE artID = ?");
        $stmt->bind_param("i",$id);
        $stmt->execute();
        $stmt->close(); $c->close();
    }

    // ── COMMENTS ────────────────────────────────────────────────────────────────

    public function getCommentsByArticle(int $aid): array {
        $c = $this->getConnection();
        $stmt = $c->prepare("SELECT * FROM comments WHERE artID = ?");
        $stmt->bind_param("i",$aid);
        $stmt->execute();
        $res = $stmt->get_result();
        $out = [];
        while($r = $res->fetch_assoc()) {
            $cm = new Comment(); $cm->load($r);
            $out[] = $cm;
        }
        $stmt->close(); $c->close();
        return $out;
    }

    public function addComment(Comment $cm): void {
        $c = $this->getConnection();
        $stmt = $c->prepare(
          "INSERT INTO comments (authorID, artID, content)
           VALUES (?, ?, ?)"
        );
        $stmt->bind_param("iis",
          $cm->getAuthorID(),
          $cm->getArtID(),
          $cm->getContent()
        );
        $stmt->execute();
        $stmt->close(); $c->close();
    }

    public function deleteComment(int $id): void {
        $c = $this->getConnection();
        $stmt = $c->prepare("DELETE FROM comments WHERE comID = ?");
        $stmt->bind_param("i",$id);
        $stmt->execute();
        $stmt->close(); $c->close();
    }
}
