<?php
class Comment {
    private $comID;
    private $authorID;
    private $artID;
    private $content;
    private $lastModified;

    public function load(array $row) {
        $this->setComID(       $row['comID']      );
        $this->setAuthorID(    $row['authorID']   );
        $this->setArtID(       $row['artID']      );
        $this->setContent(     $row['content']    );
        $this->setLastModified($row['lastModified']);
    }

    public function setComID($id)            { $this->comID        = $id; }
    public function getComID()               { return $this->comID; }

    public function setAuthorID($id)         { $this->authorID     = $id; }
    public function getAuthorID()            { return $this->authorID; }

    public function setArtID($id)            { $this->artID        = $id; }
    public function getArtID()               { return $this->artID; }

    public function setContent($c)           { $this->content      = $c; }
    public function getContent()             { return $this->content; }

    public function setLastModified($lm)     { $this->lastModified = $lm; }
    public function getLastModified()        { return $this->lastModified; }
}