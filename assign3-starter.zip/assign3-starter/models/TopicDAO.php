<?php
require_once 'Topic.php';

class TopicDAO {
    private function getConnection() {
        $m = new mysqli('localhost', 'bloguser', 'blogAssign3', 'blogdb');
        if ($m->connect_errno) {
            error_log("DB connection failed: " . $m->connect_error);
            return null;
        }
        return $m;
    }

    /** @return Topic[] */
    public function getTopics(): array {
        $conn = $this->getConnection();
        $out = [];

        if ($conn) {
            $res = $conn->query("SELECT * FROM topics");

            if (!$res) {
                error_log("Query failed: " . $conn->error);
            } else {
                while ($row = $res->fetch_assoc()) {
                    $t = new Topic();
                    $t->load($row);
                    $out[] = $t;
                }
                error_log("Fetched " . count($out) . " topics from DB.");
            }

            $conn->close();
        } else {
            error_log("No DB connection available.");
        }

        return $out;
    }

    public function addTopic(Topic $t): void {
        $c = $this->getConnection();
        if (!$c) {
            error_log("Cannot add topic: no DB connection.");
            return;
        }

        $name = $t->getName();
        $desc = $t->getDescription();

        $stmt = $c->prepare("INSERT INTO topics (name, description) VALUES (?, ?)");
        if (!$stmt) {
            error_log("Prepare failed: " . $c->error);
            return;
        }

        $stmt->bind_param("ss", $name, $desc);
        if (!$stmt->execute()) {
            error_log("Execute failed: " . $stmt->error);
        }

        $stmt->close();
        $c->close();
    }

    public function deleteTopic(int $id): void {
        $c = $this->getConnection();
        if (!$c) {
            error_log("Cannot delete topic: no DB connection.");
            return;
        }

        $stmt = $c->prepare("DELETE FROM topics WHERE topID = ?");
        if (!$stmt) {
            error_log("Prepare failed: " . $c->error);
            return;
        }

        $stmt->bind_param("i", $id);
        if (!$stmt->execute()) {
            error_log("Execute failed: " . $stmt->error);
        }

        $stmt->close();
        $c->close();
    }
}
