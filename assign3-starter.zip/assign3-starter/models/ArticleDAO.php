<?php
include_once 'Article.php';

class ArticleDAO {
    private function getConnection() {
        $m = new mysqli('localhost','bloguser','blogAssign3','blogdb');
        return $m->connect_errno ? null : $m;
    }

    /** @return Article[] */
    public function getArticles(): array {
        $conn = $this->getConnection();
        $out  = [];
        if ($conn) {
            $res = $conn->query("SELECT * FROM articles");
            while ($row = $res->fetch_assoc()) {
                $a = new Article();
                $a->load($row);
                $out[] = $a;
            }
            $conn->close();
        }
        return $out;
    }

    public function getArticleById(int $id): ?Article {
        $conn = $this->getConnection();
        if ($conn) {
            $stmt = $conn->prepare("SELECT * FROM articles WHERE artID = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $res = $stmt->get_result();
            if ($row = $res->fetch_assoc()) {
                $a = new Article();
                $a->load($row);
                $stmt->close();
                $conn->close();
                return $a;
            }
            $stmt->close();
            $conn->close();
        }
        return null;
    }

    /** @return Article[] */
    public function getArticlesByTopic(int $topicID): array {
        $conn = $this->getConnection();
        $out  = [];
        if ($conn) {
            $stmt = $conn->prepare("SELECT * FROM articles WHERE catID = ?");
            $stmt->bind_param("i", $topicID);
            $stmt->execute();
            $res = $stmt->get_result();
            while ($row = $res->fetch_assoc()) {
                $a = new Article();
                $a->load($row);
                $out[] = $a;
            }
            $stmt->close();
            $conn->close();
        }
        return $out;
    }

    public function addArticle(Article $a): void {
        $c = $this->getConnection();
        if (!$c) return;
        $stmt = $c->prepare(
            "INSERT INTO articles (authorID, catID, title, image, content)
             VALUES (?, ?, ?, ?, ?)"
        );
        $authorID = $a->getAuthorID();
        $catID    = $a->getCatID();
        $title    = $a->getTitle();
        $image    = $a->getImage();
        $content  = $a->getContent();
        $stmt->bind_param("iisss", $authorID, $catID, $title, $image, $content);
        $stmt->execute();
        $stmt->close();
        $c->close();
    }

    public function deleteArticle(int $id): void {
        $c = $this->getConnection();
        if (!$c) return;
        $stmt = $c->prepare("DELETE FROM articles WHERE artID = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();
        $c->close();
    }
}