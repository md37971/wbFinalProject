<?php
class User {
    private $userID;
    private $username;
    private $lastname;
    private $firstname;
    private $password;
    private $email;
    private $role;

    public function load(array $row) {
        $this->setUserID(  $row['userID']  );
        $this->setUsername($row['username']);
        $this->setLastname($row['lastname']);
        $this->setFirstname($row['firstname']);
        $this->setPassword($row['password']);
        $this->setEmail(   $row['email']   );
        $this->setRole(    $row['role']    );
    }

    public function setUserID($id)        { $this->userID   = $id; }
    public function getUserID()            { return $this->userID; }

    public function setUsername($u)        { $this->username = $u; }
    public function getUsername()          { return $this->username; }

    public function setLastname($l)        { $this->lastname = $l; }
    public function getLastname()          { return $this->lastname; }

    public function setFirstname($f)       { $this->firstname = $f; }
    public function getFirstname()         { return $this->firstname; }

    public function setPassword($p)        { $this->password = $p; }
    public function getPassword()          { return $this->password; }

    public function setEmail($e)           { $this->email    = $e; }
    public function getEmail()             { return $this->email; }

    public function setRole($r)            { $this->role     = $r; }
    public function getRole()              { return $this->role; }
}

?>