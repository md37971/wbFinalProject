<?php
include_once 'Comment.php';

class CommentDAO {
    private function getConnection() {
        $m = new mysqli('localhost', 'bloguser', 'blogAssign3', 'blogdb');
        return $m->connect_errno ? null : $m;
    }

    /** Add a new comment */
    public function addComment(Comment $cm): void {
        $c = $this->getConnection();
        if (!$c) return;

        $stmt = $c->prepare(
            "INSERT INTO comments (authorID, artID, content) VALUES (?, ?, ?)"
        );
        $authorID = $cm->getAuthorID();
        $artID    = $cm->getArtID();
        $content  = $cm->getContent();
        $stmt->bind_param("iis", $authorID, $artID, $content);
        $stmt->execute();
        $stmt->close();
        $c->close();
    }

    /** Get all comments */
    public function getAllComments(): array {
        $c = $this->getConnection();
        $out = [];
        if ($c) {
            $res = $c->query("SELECT * FROM comments");
            while ($row = $res->fetch_assoc()) {
                $cm = new Comment();
                $cm->load($row);
                $out[] = $cm;
            }
            $c->close();
        }
        return $out;
    }

    /** Get comments by article */
    public function getCommentsByArticle(int $artID): array {
        $c = $this->getConnection();
        $out = [];
        if ($c) {
            $stmt = $c->prepare("SELECT * FROM comments WHERE artID = ?");
            $stmt->bind_param("i", $artID);
            $stmt->execute();
            $res = $stmt->get_result();
            while ($row = $res->fetch_assoc()) {
                $cm = new Comment();
                $cm->load($row);
                $out[] = $cm;
            }
            $stmt->close();
            $c->close();
        }
        return $out;
    }
}
