<?php
class Topic {
    private $topID;
    private $name;
    private $description;
    private $lastModified;

    public function load(array $row) {
        if (!isset($row['topID']) || !isset($row['name'])) {
            error_log("Topic load(): Missing required fields in row: " . json_encode($row));
        }

        $this->setTopID($row['topID'] ?? null);
        $this->setName($row['name'] ?? '');
        $this->setDescription($row['description'] ?? '');
        $this->setLastModified($row['lastModified'] ?? '');

        error_log("Loaded Topic: ID={$this->topID}, Name={$this->name}");
    }

    public function setTopID($id) { $this->topID = $id; }
    public function getTopID()    { return $this->topID; }

    public function setName($n)   { $this->name = $n; }
    public function getName()     { return $this->name; }

    public function setDescription($d) { $this->description = $d; }
    public function getDescription()   { return $this->description; }

    public function setLastModified($lm) { $this->lastModified = $lm; }
    public function getLastModified()    { return $this->lastModified; }
}
