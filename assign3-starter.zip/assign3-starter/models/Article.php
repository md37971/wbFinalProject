<?php
class Article {
    private $artID;
    private $authorID;
    private $catID;
    private $title;
    private $image;
    private $content;
    private $lastModified;

    public function load(array $row) {
        $this->setArtID(       $row['artID']       );
        $this->setAuthorID(    $row['authorID']    );
        $this->setCatID(       $row['catID']       );
        $this->setTitle(       $row['title']       );
        $this->setImage(       $row['image']       );
        $this->setContent(     $row['content']     );
        $this->setLastModified($row['lastModified']);
    }

    public function setArtID($id)            { $this->artID        = $id; }
    public function getArtID()               { return $this->artID; }

    public function setAuthorID($id)         { $this->authorID     = $id; }
    public function getAuthorID()            { return $this->authorID; }

    public function setCatID($id)            { $this->catID        = $id; }
    public function getCatID()               { return $this->catID; }

    public function setTitle($t)             { $this->title        = $t; }
    public function getTitle()               { return $this->title; }

    public function setImage($i)             { $this->image        = $i; }
    public function getImage()               { return $this->image; }

    public function setContent($c)           { $this->content      = $c; }
    public function getContent()             { return $this->content; }

    public function setLastModified($lm)     { $this->lastModified = $lm; }
    public function getLastModified()        { return $this->lastModified; }
}