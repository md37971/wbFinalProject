<?php

class User {
    private $userID, $username, $lastname, $firstname, $password, $email, $role, $lastModified;

    public function load(array $row) {
        $this->userID      = $row['userID'];
        $this->username    = $row['username'];
        $this->lastname    = $row['lastname'];
        $this->firstname   = $row['firstname'];
        $this->password    = $row['password'];
        $this->email       = $row['email'];
        $this->role        = $row['role'];
        $this->lastModified= $row['lastModified'];
    }

    public function setUserID($v){ $this->userID = $v; }
    public function getUserID(){ return $this->userID; }
    public function setUsername($v){ $this->username = $v; }
    public function getUsername(){ return $this->username; }
    public function setLastname($v){ $this->lastname = $v; }
    public function getLastname(){ return $this->lastname; }
    public function setFirstname($v){ $this->firstname = $v; }
    public function getFirstname(){ return $this->firstname; }
    public function setPassword($v){ $this->password = $v; }
    public function getPassword(){ return $this->password; }
    public function setEmail($v){ $this->email = $v; }
    public function getEmail(){ return $this->email; }
    public function setRole($v){ $this->role = $v; }
    public function getRole(){ return $this->role; }
    public function getLastModified(){ return $this->lastModified; }
}

class Topic {
    private $topID, $name, $description, $lastModified;

    public function load(array $row) {
        $this->topID        = $row['topID'];
        $this->name         = $row['name'];
        $this->description  = $row['description'];
        $this->lastModified = $row['lastModified'];
    }

    public function setTopID($v){ $this->topID = $v; }
    public function getTopID(){ return $this->topID; }
    public function setName($v){ $this->name = $v; }
    public function getName(){ return $this->name; }
    public function setDescription($v){ $this->description = $v; }
    public function getDescription(){ return $this->description; }
    public function getLastModified(){ return $this->lastModified; }
}

class Article {
    private $artID, $authorID, $catID, $title, $image, $content, $lastModified;

    public function load(array $row) {
        $this->artID        = $row['artID'];
        $this->authorID     = $row['authorID'];
        $this->catID        = $row['catID'];
        $this->title        = $row['title'];
        $this->image        = $row['image'];
        $this->content      = $row['content'];
        $this->lastModified = $row['lastModified'];
    }

    public function setArtID($v){ $this->artID = $v; }
    public function getArtID(){ return $this->artID; }
    public function setAuthorID($v){ $this->authorID = $v; }
    public function getAuthorID(){ return $this->authorID; }
    public function setCatID($v){ $this->catID = $v; }
    public function getCatID(){ return $this->catID; }
    public function setTitle($v){ $this->title = $v; }
    public function getTitle(){ return $this->title; }
    public function setImage($v){ $this->image = $v; }
    public function getImage(){ return $this->image; }
    public function setContent($v){ $this->content = $v; }
    public function getContent(){ return $this->content; }
    public function getLastModified(){ return $this->lastModified; }
}

class Comment {
    private $comID, $authorID, $artID, $content, $lastModified;

    public function load(array $row) {
        $this->comID        = $row['comID'];
        $this->authorID     = $row['authorID'];
        $this->artID        = $row['artID'];
        $this->content      = $row['content'];
        $this->lastModified = $row['lastModified'];
    }

    public function setComID($v){ $this->comID = $v; }
    public function getComID(){ return $this->comID; }
    public function setAuthorID($v){ $this->authorID = $v; }
    public function getAuthorID(){ return $this->authorID; }
    public function setArtID($v){ $this->artID = $v; }
    public function getArtID(){ return $this->artID; }
    public function setContent($v){ $this->content = $v; }
    public function getContent(){ return $this->content; }
    public function getLastModified(){ return $this->lastModified; }
}
