<!DOCTYPE html>
<html lang="en">
<style>
  
.article {
  display: flex;
  flex-direction: row;
  padding-left: 4%;

}

.theTable{
  margin-right: 5%;
}

#t1 {
  padding-right: 5%;
}

#t2 {
  padding-left: 0%;
}
</style>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Home Page</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

</head>
<body>

<div class="article"> <!--container-->
  <div class="theTable" id="t1">
    <form action="controller.php" method="GET">
    <h3 style="text-align: left"><u><b>What's currently happening?</b></u></h3>  
      <table class="table table-bordered table-striped">
        <thead>
          <tr>
            <th>Article #</th>
            <th>Author</th>
            <th>Title</th>
            <th>Cat ID</th>
            <th>Image</th>
            <th>Content Descrption</th>
            <th>Last Modified</th>
            <th>Primary Key</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>000</td>
            <td>John Doe</td>
            <td>The Title of this article is really long and dumb.</td>
            <td>342</td>
            <td>FFFFFFFFFFFFFFFFFFFFFFFFFFFFFf</td>
            <td>Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellendus dolores ut dolorum, in, doloribus doloremque, dignissimos nisi minus ex beatae nulla magnam vero non exercitationem error obcaecati vitae reprehenderit a!</td>
            <td>01/25/2015</td>
            <td>32536235</td>
          </tr>
          <tr>
            <td>X</td>
            <td>X</td>
            <td>X</td>
            <td>X</td>
            <td>X</td>
            <td>X</td>
            <td>X</td>
            <td>X</td>
          </tr>
          
        <?php
                        /*
                        for($index=0;$index<count($contacts);$index++){
                            echo "<tr><td><input type=\"radio\" name=\"contactID\" value=\"".$contacts[$index]->getContactID()."\"></td>";
                            echo "<td>".$contacts[$index]->getUsername()."</td>";
                            echo "<td>".$contacts[$index]->getEmail()."</td>";
                            echo "<td>".$contacts[$index]->getPasswd()."</td></tr>";
                        }
                            */
        ?>
        </tbody>        
      </table> 
    </form>
  </div>



  <div class="theTable" id="t2"> <!--container-->
    <form action="controller.php" method="GET">
    <h3><b><u>Topics</u></b></h3>    
            <!--
            <button class="btn btn-primary" type="submit" name="page" value="add">Add Contact</button>
            <button class="btn btn-primary" type="submit" name="page" value="delete">Delete Contact</button>
            -->
    <table class="table table-bordered table-striped">     
    <thead>
      <tr>
        <th>Topic ID #</th>
        <th>Topic Name</th>
        <th>Topic Descrption</th>
        <th>Last Modified</th>
      </tr>
        </thead>
            <tbody>
            <tr>
              <td>X</td>
              <td>X</td>
              <td>X</td>
              <td>X</td>
            </tr>
            <tr>
              <td>X</td>
              <td>X</td>
              <td>X</td>
              <td>X</td>
            </tr>
            <?php
      
            ?>
        </tbody>        
      </table>  
    </form>
    </div>
</div>
</body>
</html>


  <!--BOOTSTRAP BODY TEMPLATE TO CHANGESSSSS-->
  <!---
  <main class="container">
  <div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
    <h1 class="display-4">Pricing</h1>
    <p class="lead">Quickly build an effective pricing table for your potential customers with this Bootstrap example. It’s built with default Bootstrap components and utilities with little customization.</p>
  </div>

  <div class="row row-cols-1 row-cols-md-3 mb-3 text-center">
    <div class="col">
      <div class="card mb-4 shadow-sm">
      <div class="card-header">
        <h4 class="my-0 fw-normal">Free</h4>
      </div>
      <div class="card-body">
        <h1 class="card-title pricing-card-title">$0 <small class="text-muted">/ mo</small></h1>
        <ul class="list-unstyled mt-3 mb-4">
          <li>10 users included</li>
          <li>2 GB of storage</li>
          <li>Email support</li>
          <li>Help center access</li>
        </ul>
        <button type="button" class="w-100 btn btn-lg btn-outline-primary">Sign up for free</button>
      </div>
    </div>
    </div>
    <div class="col">
      <div class="card mb-4 shadow-sm">
      <div class="card-header">
        <h4 class="my-0 fw-normal">Pro</h4>
      </div>
      <div class="card-body">
        <h1 class="card-title pricing-card-title">$15 <small class="text-muted">/ mo</small></h1>
        <ul class="list-unstyled mt-3 mb-4">
          <li>20 users included</li>
          <li>10 GB of storage</li>
          <li>Priority email support</li>
          <li>Help center access</li>
        </ul>
        <button type="button" class="w-100 btn btn-lg btn-primary">Get started</button>
      </div>
    </div>
    </div>
    <div class="col">
      <div class="card mb-4 shadow-sm">
      <div class="card-header">
        <h4 class="my-0 fw-normal">Enterprise</h4>
      </div>
      <div class="card-body">
        <h1 class="card-title pricing-card-title">$29 <small class="text-muted">/ mo</small></h1>
        <ul class="list-unstyled mt-3 mb-4">
          <li>30 users included</li>
          <li>15 GB of storage</li>
          <li>Phone and email support</li>
          <li>Help center access</li>
        </ul>
        <button type="button" class="w-100 btn btn-lg btn-primary">Contact us</button>
      </div>
    </div>
    </div>
  </div>
</main>
</body>
-->



</html>

