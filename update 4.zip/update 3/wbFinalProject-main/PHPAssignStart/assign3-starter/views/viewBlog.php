<?php
    $articles = $_REQUEST['articles'];
    $users    = $_REQUEST['users'];
    $topics   = $_REQUEST['topics'];
    $comments = $_REQUEST['comments'];

    // build quick lookups
    $usernames  = [];
    foreach($users as $u) {
        $usernames[ $u->getUserID() ] = $u->getUsername();
    }
    $topicNames = [];
    foreach($topics as $t) {
        $topicNames[ $t->getTopID() ] = $t->getName();
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Blog Overview</title>
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
    rel="stylesheet"
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
    crossorigin="anonymous"
  >
</head>
<body>
  <div class="container py-5">
    <form action="controller.php" method="GET">
      <h1 class="text-center mb-4">All Blog Articles</h1>
      <div class="mb-3">
        <button class="btn btn-primary" type="submit" name="page" value="addArticle">
          Add Article
        </button>
        <button class="btn btn-danger"  type="submit" name="page" value="deleteArticle">
          Delete Article
        </button>
      </div>
      <table class="table table-bordered table-striped">
        <thead class="table-light">
          <tr>
            <th>Select</th>
            <th>Title</th>
            <th>Author</th>
            <th>Topic</th>
            <th>Comments</th>
            <th>Last Modified</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($articles as $art): 
              // count comments for this article
              $cnt = 0;
              foreach ($comments as $c) {
                  if ($c->getArtID() === $art->getArtID()) {
                      $cnt++;
                  }
              }
          ?>
          <tr>
            <td>
              <input
                type="radio"
                name="artID"
                value="<?= $art->getArtID() ?>"
              >
            </td>
            <td><?= htmlspecialchars($art->getTitle()) ?></td>
            <td><?= htmlspecialchars($usernames[ $art->getAuthorID() ] ?? 'Unknown') ?></td>
            <td><?= htmlspecialchars($topicNames[ $art->getCatID() ]   ?? 'Unknown') ?></td>
            <td><?= $cnt ?></td>
            <td><?= htmlspecialchars($art->getLastModified()) ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </form>
  </div>
</body>
</html>
