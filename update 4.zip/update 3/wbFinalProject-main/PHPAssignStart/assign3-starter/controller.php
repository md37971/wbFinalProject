<?php
include_once "controllers/ControllerAction.php";
include_once "controllers/ContactControllers.php";
include_once "models/ContactDAO.php";

class FrontController { 
    private $controllers;
    
    public function __construct(){
        $this->showErrors(0);
        $this->controllers = $this->loadControllers();
    }

    public function run(){
        session_start();

        //***** 1. Get Request Method and Page Variable *****/
        $method = $_SERVER['REQUEST_METHOD'];
        $page   = $_REQUEST['page'] ?? 'home';

        //***** 2. Route the Request to the Controller Based on Method and Page *** */
        $key        = $method . $page;
        $controller = $this->controllers[$key] ?? $this->controllers["GEThome"];
        
        //** 3. Check Security Access ***/
        $controller = $this->securityCheck($controller);

        //** 4. Execute the Controller */
        if ($method === 'GET') {
            $content = $controller->processGET();
        } else {
            $content = $controller->processPOST();
        }

        //**** 5. Render Page Template */
        include "template/template.php";
    }

    private function loadControllers(){
        /******************************************************
         * Register the Controllers with the Front Controller *
         ******************************************************/
        $controllers["GETlist"]       = new ContactList();
        $controllers["GETadd"]        = new ContactAdd();
        $controllers["POSTadd"]       = new ContactAdd();
        $controllers["GETdelete"]     = new ContactDelete();
        $controllers["POSTdelete"]    = new ContactDelete();
        $controllers["GETlogin"]      = new Login();
        $controllers["POSTlogin"]     = new Login();
        $controllers["GEThome"]       = new Home();
        $controllers["GETabout"]      = new About();

        // ── BLOG ROUTES ──────────────────────────────────────
        $controllers["GETlistBlog"]   = new ArticleList();
        $controllers["GETviewBlog"]   = new ArticleView();
        $controllers["POSTaddComment"]= new CommentAdd();

        return $controllers;
    }

    private function securityCheck($controller){
        /******************************************************
         * Check Access restrictions for selected controller  *
         ******************************************************/
        if ($controller->getAccess() === 'PROTECTED' && empty($_SESSION['loggedin'])) {
            // Not logged in → force login page
            return $this->controllers["GETlogin"];
        }
        return $controller;
    }

    private function showErrors($debug){
        if ($debug === 1) {
            ini_set('display_errors', 1);
            ini_set('display_startup_errors', 1);
            error_reporting(E_ALL);
        }
    }
}

$controller = new FrontController();
$controller->run();
