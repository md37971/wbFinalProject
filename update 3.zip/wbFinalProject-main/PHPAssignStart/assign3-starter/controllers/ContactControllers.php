<?php
// controllers/ContactControllers.php

require_once __DIR__ . '/ControllerAction.php';
require_once __DIR__ . '/../models/ContactDAO.php';
require_once __DIR__ . '/../models/Contact.php';
require_once __DIR__ . '/../models/BlogDAO.php';
require_once __DIR__ . '/../models/Blog.php';

//
// ── CONTACT CONTROLLERS ───────────────────────────────────────────────────────
//

class ContactList implements ControllerAction {
    public function processGET() {
        $contactDAO           = new ContactDAO();
        $contacts             = $contactDAO->getContacts();
        $_REQUEST['contacts'] = $contacts;
        return 'views/listContact.php';
    }
    public function processPOST() { /* no POST here */ }
    public function getAccess()   { return 'PROTECTED'; }
}

class ContactAdd implements ControllerAction {
    public function processGET() {
        return 'views/addContact.php';
    }
    public function processPOST() {
        $username = $_POST['username'] ?? '';
        $email    = $_POST['email']    ?? '';
        $passwd   = $_POST['passwd']   ?? '';

        $contact = new Contact();
        $contact->setUsername($username);
        $contact->setEmail($email);
        $contact->setPasswd($passwd);

        $contactDAO = new ContactDAO();
        $contactDAO->addContact($contact);

        header('Location: controller.php?page=list');
        exit;
    }
    public function getAccess()   { return 'PROTECTED'; }
}

class ContactDelete implements ControllerAction {
    public function processGET() {
        $contactID              = $_GET['contactID'] ?? null;
        $_REQUEST['contactID']  = $contactID;
        return 'views/delContact.php';
    }
    public function processPOST() {
        $contactID = $_POST['contactID'] ?? null;
        $submit    = $_POST['submit']    ?? '';

        if ($submit === 'CONFIRM' && $contactID) {
            (new ContactDAO())->deleteContact($contactID);
        }

        header('Location: controller.php?page=list');
        exit;
    }
    public function getAccess()   { return 'PROTECTED'; }
}

class Login implements ControllerAction {
    public function processGET() {
        return 'views/login.php';
    }
    public function processPOST() {
        session_start();
        $username = $_POST['username'] ?? '';
        $passwd   = $_POST['passwd']   ?? '';

        $found = (new ContactDAO())->authenticate($username, $passwd);
        if ($found) {
            $_SESSION['loggedin'] = true;
            header('Location: controller.php?page=list');
        } else {
            header('Location: controller.php?page=login&error=invalid');
        }
        exit;
    }
    public function getAccess()   { return 'PUBLIC'; }
}

class Home implements ControllerAction {
    public function processGET() {
        return 'views/home.php';
    }
    public function processPOST() { /* none */ }
    public function getAccess()   { return 'PUBLIC'; }
}

class About implements ControllerAction {
    public function processGET() {
        return 'views/about.php';
    }
    public function processPOST() { /* none */ }
    public function getAccess()   { return 'PUBLIC'; }
}

//
// ── BLOG CONTROLLERS ──────────────────────────────────────────────────────────
//

class ArticleList implements ControllerAction {
    public function processGET() {
        $articles              = (new BlogDAO())->getArticles();
        $_REQUEST['articles']  = $articles;
        return 'views/listBlog.php';
    }
    public function processPOST() { /* none */ }
    public function getAccess()   { return 'PUBLIC'; }
}

class ArticleView implements ControllerAction {
    public function processGET() {
        $artID = isset($_GET['artID']) ? (int)$_GET['artID'] : 0;
        $dao         = new BlogDAO();
        $article     = $dao->getArticleById($artID);
        $comments    = $dao->getCommentsByArticle($artID);

        $_REQUEST['article']  = $article;
        $_REQUEST['comments'] = $comments;
        return 'views/viewBlog.php';
    }
    public function processPOST() { /* none */ }
    public function getAccess()   { return 'PUBLIC'; }
}

class CommentAdd implements ControllerAction {
    public function processGET() { /* no GET */ }
    public function processPOST() {
        session_start();
        $artID   = (int)($_POST['artID']   ?? 0);
        $content = trim($_POST['content'] ?? '');
        $userID  = $_SESSION['userID']    ?? null;

        if ($userID && $content !== '') {
            $c = new Comment();
            $c->setAuthorID($userID);
            $c->setArtID($artID);
            $c->setContent($content);
            (new BlogDAO())->addComment($c);
        }
        header("Location: controller.php?page=viewBlog&artID={$artID}");
        exit;
    }
    public function getAccess()   { return 'PROTECTED'; }
}
