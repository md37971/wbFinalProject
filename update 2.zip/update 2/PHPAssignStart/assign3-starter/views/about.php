<?php
session_start();  // make sure sessions are available
$status   = isset($_SESSION['loggedin']) ? "Logged In" : "Login";
$class    = isset($_SESSION['loggedin']) ? "disabled"  : "";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About Section</title>
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
    rel="stylesheet"
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
    crossorigin="anonymous"
  >
</head>
<body>
  <header class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-body border-bottom shadow-sm">
    <p class="h5 my-0 me-md-auto fw-normal">CS 2033: Web Systems MVC Pattern with Authorization</p>
    <nav class="my-2 my-md-0 me-md-3">
      <a class="p-2 text-dark" href="../controller.php?page=home">Home</a>
      <a class="p-2 text-dark" href="../controller.php?page=about">About</a>
      <a class="p-2 text-dark" href="../controller.php?page=list">Admin</a>
    </nav>
    <a class="btn btn-outline-primary <?php echo $class; ?>"
       href="controller.php?page=login">
      <?php echo $status; ?>
    </a>
  </header>

  <main class="container">
    <div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
      <h1 class="display-4">About</h1>
      <p class="lead">This is the about section.</p>
      <ul>
        <li>Test</li>
        <li>Test</li>
        <li>Test</li>
        <li>Test</li>
        <li>Test</li>
        <li>Test</li>
        <li>Test</li>
      </ul>
    </div>
  </main>

  <footer class="pt-4 my-md-5 pt-md-5 border-top">
    <!-- footer content unchanged -->
  </footer>
</body>
</html>
